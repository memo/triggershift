package controlP5;

class Console {
	// http://www.comweb.nl/java/Console/Console.html
}
